<?php

define('HOST', '');
define('USER', '');
define('PASSWORD', '');
define('DATABASE_NAME', '');

define('CURRENCY', '₱');



?>