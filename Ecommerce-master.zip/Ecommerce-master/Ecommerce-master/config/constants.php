<?php

define('HOST', 'remotemysql.com');
define('USER', 'KJVKfZ3rEC');
define('PASSWORD', 'U4WywZ7oIs');
define('DATABASE_NAME', 'KJVKfZ3rEC');

define('CURRENCY', '₱');



?>