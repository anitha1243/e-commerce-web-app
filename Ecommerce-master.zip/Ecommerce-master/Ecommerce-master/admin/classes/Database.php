<?php

/**
 * 
 */
class Database
{
	
	private $con;
	public function connect(){
		$this->con = new Mysqli("remotemysql.com", "KJVKfZ3rEC", "U4WywZ7oIs", "KJVKfZ3rEC");
		return $this->con;
	}
}

?>