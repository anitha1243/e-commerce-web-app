<?php

require "config/constants.php";

$servername = 'remotemysql.com';
$username = 'KJVKfZ3rEC';
$password = 'U4WywZ7oIs';
$db = 'KJVKfZ3rEC';

// Create connection
$con = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


?>