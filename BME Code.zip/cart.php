<?php
session_start();
require "config/constants.php";

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Barangay Market Express</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css"/>
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-brand">Barangay Market Express</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
			</ul>
		</div>
	</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="cart_msg">
				<!--Cart Message--> 
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">Cart Checkout</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-2 col-xs-2"><b>Action</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Image</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Name</b></div>
							<div class="col-md-2 col-xs-2"><b>Quantity</b></div>
							<div class="col-md-2 col-xs-2"><b>Product Price</b></div>
							<div class="col-md-2 col-xs-2"><b>Price in <?php echo CURRENCY; ?></b></div>
						</div>
						<div id="cart_checkout"></div></br><form method="POST">
<label>Delivery Address:</label><div id="del_address"></div>
<label>Enter Note below (For example door number):</label> <textarea id="notes" class="form-control"></textarea><form>
<?php $lat_long = $_SESSION["lat_long_session"];

$position = strpos($lat_long, '(');
$lat_long= substr($lat_long, $position+1);//get substring after this position
$lat_text = substr($lat_long, 0, strpos($lat_long,','));
$long_txt = substr($lat_long, strpos($lat_long,',')+1);
$long_txt = substr($long_txt, 0, strpos($long_txt,')'));
$long_txt = trim($long_txt);

$_SESSION["deliver_lat"] = $lat_text;
$_SESSION["deliver_long"] = $long_txt;


?>
<div id="del_lat" style="visibility:hidden"><?php echo $lat_text; ?></div>
<div id="del_long" style="visibility:hidden"><?php echo $long_txt; ?></div>


						</div> 
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
			
		</div>

<script>var CURRENCY = '<?php echo CURRENCY; ?>';
var del_lat = document.getElementById("del_lat").textContent;
var del_long = document.getElementById("del_long").textContent;

$.get('https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat='+ del_lat +'&lon='+ del_long +'', function(data){

  var completeAddress = data.address.house_number + " " + data.address.road + " " + data.address.city + " " + data.address.postcode + " " + data.address.country + " "
  var address = completeAddress.replace(/undefined/g, "");
  document.getElementById("del_address").textContent = address;
  $.ajax({
		url : "action.php",
		method : "POST",
	    data : {getDelAddr:1,deliver_addr:completeAddress},

})


});

$("body").delegate("#notes","click",function(event){

var notesOrder =  document.getElementById("notes").value;

            $.ajax({
			url : "action.php",
			method : "POST",
			data : {getNotes:1,notesArg:notesOrder},

		})

})

</script>
</body>	
</html>
















		