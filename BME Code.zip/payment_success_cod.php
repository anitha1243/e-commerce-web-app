<?php
error_reporting(0);
session_start();
$uid=$_SESSION["uid"];
if(!isset($_SESSION["uid"])){

header("location:index.php");
}

		include_once("db.php");
		$sql = "SELECT p_id,qty FROM cart WHERE user_id = '$uid'";
		$query = mysqli_query($con,$sql);

			# code...
			while ($row=mysqli_fetch_array($query)) {
			$product_id[] = $row["p_id"];
			$qty[] = $row["qty"];
			}
            $trx_id = rand(0,99999999999999999);
            $p_st ="Completed";
            $del_add = $_SESSION["deliver_addr"];
            $notes = $_SESSION["del_notes"];
            $deliver_adress= $notes ."/".$del_add;
            $del_lat = $_SESSION['deliver_lat'];

            $del_long = $_SESSION['deliver_long'];

            $order_fulfil_type_id = $_SESSION["order_fulfilment_type_id"];

			for ($i=0; $i < count($product_id); $i++) {

				$sql = "INSERT INTO orders (user_id,product_id,qty,trx_id,p_status,delivery_address, delivery_lat, delivery_long, order_fulfillment_type_id) VALUES ('$uid','".$product_id[$i]."','".$qty[$i]."','$trx_id','$p_st', '$deliver_adress', '$del_lat', '$del_long','$order_fulfil_type_id')";
                $message .= "\n"."User Id: ".$uid." Product Id: ".$product_id[$i]." Quantity: ".$qty[$i]." Transaction Id: ".$trx_id." Delivery Address: ".$deliver_adress."If Pick Up then 1 If Delivery then 2 =>".$order_fulfil_type_id."\n"."======================================";
				mysqli_query($con,$sql);
			}

			$sql = "DELETE FROM cart WHERE user_id = '$uid'";
            $query = mysqli_query($con,$sql);


$to = "brgymarketexpress@gmail.com";
$subject = "Order Transaction Id:".$trx_id;
$from = "brgymarketexpress@gmail.com";
$headers = "From:" . $from;
mail($to,$subject,$message,$headers);




				?>
					<!DOCTYPE html>
					<html>
						<head>
							<meta charset="UTF-8">
							<title>Barangay Market Express</title>
							<link rel="stylesheet" href="css/bootstrap.min.css"/>
							<script src="js/jquery2.js"></script>
							<script src="js/bootstrap.min.js"></script>
							<script src="main.js"></script>
							<style>
								table tr td {padding:10px;}
							</style>
						</head>
					<body>
						<div class="navbar navbar-inverse navbar-fixed-top">
							<div class="container-fluid">
								<div class="navbar-header">
									<a href="index.php" class="navbar-brand">Barangay Market Express</a>
								</div>
								<ul class="nav navbar-nav">
									<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
									<li><a href="products.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
								</ul>
							</div>
						</div>
						<p><br/></p>
						<p><br/></p>
						<p><br/></p>
						<div class="container-fluid">

							<div class="row">
								<div class="col-md-2"></div>
								<div class="col-md-8">
									<div class="panel panel-default">
										<div class="panel-heading"></div>
										<div class="panel-body">
											<h1>Thankyou </h1>
											<hr/>
											<p>Hello <?php echo "<b>".$_SESSION["name"]."</b>"; ?>,Your order has been successfully placed and your Transaction id is <b><?php echo $trx_id; ?></b><br/>
											you can continue your Shopping <br/></p>
											<a href="index.php" class="btn btn-success btn-lg">Continue Shopping</a>
										</div>
										<div class="panel-footer"></div>
									</div>
								</div>
								<div class="col-md-2"></div>
							</div>
						</div>
					</body>
					</html>
